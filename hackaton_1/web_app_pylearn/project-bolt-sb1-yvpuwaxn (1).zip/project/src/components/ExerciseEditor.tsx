import { useState } from 'react';
import { highlightPython, renderTokens } from '@/lib/highlight';
import { usePyodide } from '@/lib/usePyodide';
import type { Exercise, FeedbackStatus } from '@/types';
import { CheckCircle2, XCircle, RotateCcw, Play, Loader2, Terminal } from 'lucide-react';

interface ExerciseEditorProps {
  exercise: Exercise;
  onCorrect: () => void;
}

export function ExerciseEditor({ exercise, onCorrect }: ExerciseEditorProps) {
  const [answer, setAnswer] = useState('');
  const [status, setStatus] = useState<FeedbackStatus>('idle');
  const [hasChecked, setHasChecked] = useState(false);
  const pyodide = usePyodide();

  const normalize = (s: string) => s.trim().replace(/\s+/g, ' ');

  const checkAnswer = () => {
    const normalized = normalize(answer);
    const accepted = [exercise.correctAnswer, ...exercise.acceptedAnswers].map(normalize);
    if (accepted.includes(normalized)) {
      setStatus('correct');
      setHasChecked(true);
      onCorrect();
    } else {
      setStatus('incorrect');
      setHasChecked(true);
    }
  };

  const tryAgain = () => {
    setAnswer('');
    setStatus('idle');
    setHasChecked(false);
    pyodide.resetOutput();
  };

  const runCode = () => {
    pyodide.runCode(exercise.completeSolution);
  };

  const beforeLines = exercise.codeBeforeGap.split('\n');
  const afterLines = exercise.codeAfterGap ? exercise.codeAfterGap.split('\n') : [];
  const afterStartsWithNewline = exercise.codeAfterGap.startsWith('\n');

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-gray-900 mb-2">Exercise</h3>
        <p className="text-gray-600">{exercise.instruction}</p>
      </div>

      {/* Code editor with gap */}
      <div className="overflow-hidden rounded-xl bg-[#1e1e2e] shadow-lg">
        <div className="flex items-center gap-1.5 px-4 py-2.5 border-b border-white/5">
          <span className="w-3 h-3 rounded-full bg-[#ff5f56]" />
          <span className="w-3 h-3 rounded-full bg-[#ffbd2e]" />
          <span className="w-3 h-3 rounded-full bg-[#27c93f]" />
          <span className="ml-2 text-xs font-medium text-gray-400 font-mono">exercise.py</span>
        </div>
        <div className="code-scroll overflow-x-auto py-4">
          <pre className="font-mono text-sm leading-relaxed">
            <code>
              {/* Before gap */}
              {beforeLines.map((line, idx) => (
                <div key={`b-${idx}`} className="flex px-4">
                  <span className="select-none text-gray-600 w-8 shrink-0 text-right pr-4">
                    {idx + 1}
                  </span>
                  <span className="text-gray-100 whitespace-pre">
                    {line === '' ? ' ' : renderTokens(highlightPython(line))}
                  </span>
                </div>
              ))}
              {/* Gap line */}
              <div className="flex px-4 items-center">
                <span className="select-none text-gray-600 w-8 shrink-0 text-right pr-4">
                  {beforeLines.length + 1}
                </span>
                <input
                  type="text"
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && answer.trim()) checkAnswer();
                  }}
                  placeholder="fill in here"
                  spellCheck={false}
                  autoCapitalize="off"
                  autoComplete="off"
                  aria-label="Fill in the missing code"
                  className="bg-brand-500/15 border-b-2 border-brand-400 text-brand-200 font-mono text-sm px-2 py-0.5 rounded outline-none focus:border-brand-300 focus:bg-brand-500/25 transition-colors min-w-[140px] placeholder:text-gray-500"
                />
                <span className="whitespace-pre text-gray-100">
                  {afterStartsWithNewline ? '' : exercise.codeAfterGap}
                </span>
              </div>
              {/* After gap */}
              {afterLines.slice(afterStartsWithNewline ? 1 : 0).map((line, idx) => (
                <div key={`a-${idx}`} className="flex px-4">
                  <span className="select-none text-gray-600 w-8 shrink-0 text-right pr-4">
                    {beforeLines.length + 2 + idx}
                  </span>
                  <span className="text-gray-100 whitespace-pre">
                    {line === '' ? ' ' : renderTokens(highlightPython(line))}
                  </span>
                </div>
              ))}
            </code>
          </pre>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={checkAnswer}
          disabled={!answer.trim()}
          className="flex items-center gap-2 px-6 py-3 bg-brand-600 text-white font-semibold rounded-xl hover:bg-brand-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
        >
          <CheckCircle2 size={20} />
          Check Answer
        </button>
        {pyodide.ready && (
          <button
            onClick={runCode}
            className="flex items-center gap-2 px-5 py-3 bg-gray-800 text-white font-semibold rounded-xl hover:bg-gray-900 transition-colors"
          >
            <Play size={18} />
            Run Code
          </button>
        )}
        {pyodide.loading && !pyodide.ready && (
          <span className="flex items-center gap-2 text-sm text-gray-500 py-3">
            <Loader2 size={16} className="animate-spin" />
            Loading Python runtime...
          </span>
        )}
        {hasChecked && status === 'incorrect' && (
          <button
            onClick={tryAgain}
            className="flex items-center gap-2 px-5 py-3 bg-gray-100 text-gray-700 font-semibold rounded-xl hover:bg-gray-200 transition-colors"
          >
            <RotateCcw size={18} />
            Try Again
          </button>
        )}
      </div>

      {/* Pyodide output */}
      {pyodide.output && (
        <div className="rounded-xl bg-gray-900 border border-gray-700 overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-2 border-b border-gray-700">
            <Terminal size={14} className="text-gray-400" />
            <span className="text-xs font-medium text-gray-400 font-mono">Output</span>
          </div>
          <pre className="px-4 py-3 text-sm font-mono text-green-300 whitespace-pre-wrap max-h-48 overflow-y-auto code-scroll">
            {pyodide.output}
          </pre>
        </div>
      )}

      {/* Feedback */}
      {status === 'correct' && (
        <div className="rounded-xl bg-green-50 border border-green-200 p-5 animate-slide-up">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 className="text-green-600 shrink-0" size={24} />
            <span className="text-lg font-bold text-green-800">Correct!</span>
          </div>
          <p className="text-green-700">{exercise.answerExplanation}</p>
        </div>
      )}

      {status === 'incorrect' && (
        <div className="rounded-xl bg-red-50 border border-red-200 p-5 animate-slide-up space-y-4">
          <div className="flex items-center gap-2">
            <XCircle className="text-red-600 shrink-0" size={24} />
            <span className="text-lg font-bold text-red-800">Not quite.</span>
          </div>

          <div>
            <p className="text-sm font-semibold text-red-800 mb-1">Correct answer:</p>
            <code className="inline-block bg-red-100 text-red-900 px-3 py-1 rounded-lg font-mono text-sm">
              {exercise.correctAnswer}
            </code>
          </div>

          <div>
            <p className="text-sm font-semibold text-red-800 mb-2">Complete code:</p>
            <div className="overflow-hidden rounded-lg bg-[#1e1e2e]">
              <div className="code-scroll overflow-x-auto py-3">
                <pre className="font-mono text-sm leading-relaxed text-gray-100 px-4 whitespace-pre">
                  {exercise.completeSolution}
                </pre>
              </div>
            </div>
          </div>

          <div>
            <p className="text-sm font-semibold text-red-800 mb-1">Why this works:</p>
            <p className="text-red-700">{exercise.answerExplanation}</p>
          </div>
        </div>
      )}
    </div>
  );
}
