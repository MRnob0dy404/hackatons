import { Code2 } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t border-gray-200 bg-gray-50 mt-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 font-semibold text-gray-700">
            <span className="flex items-center justify-center w-7 h-7 rounded-md bg-brand-600 text-white">
              <Code2 size={16} />
            </span>
            PyLearn
          </div>
          <p className="text-sm text-gray-500">
            Free Python learning for everyone
          </p>
        </div>
      </div>
    </footer>
  );
}
