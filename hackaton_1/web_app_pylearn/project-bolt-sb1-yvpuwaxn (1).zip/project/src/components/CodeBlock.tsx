import { useMemo } from 'react';
import { highlightPython, renderTokens } from '@/lib/highlight';

interface CodeBlockProps {
  code: string;
  showLineNumbers?: boolean;
  className?: string;
}

export function CodeBlock({ code, showLineNumbers = true, className = '' }: CodeBlockProps) {
  const lines = useMemo(() => code.split('\n'), [code]);

  return (
    <div className={`overflow-hidden rounded-xl bg-[#1e1e2e] ${className}`}>
      <div className="flex items-center gap-1.5 px-4 py-2.5 border-b border-white/5">
        <span className="w-3 h-3 rounded-full bg-[#ff5f56]" />
        <span className="w-3 h-3 rounded-full bg-[#ffbd2e]" />
        <span className="w-3 h-3 rounded-full bg-[#27c93f]" />
        <span className="ml-2 text-xs font-medium text-gray-400 font-mono">Python</span>
      </div>
      <div className="code-scroll overflow-x-auto py-4">
        <pre className="font-mono text-sm leading-relaxed">
          <code>
            {lines.map((line, idx) => (
              <div key={idx} className="flex px-4">
                {showLineNumbers && (
                  <span className="select-none text-gray-600 w-8 shrink-0 text-right pr-4">
                    {idx + 1}
                  </span>
                )}
                <span className="text-gray-100 whitespace-pre">
                  {line === '' ? ' ' : renderTokens(highlightPython(line))}
                </span>
              </div>
            ))}
          </code>
        </pre>
      </div>
    </div>
  );
}
