import { Code2, Flame, Menu, X } from 'lucide-react';
import { useState } from 'react';
import type { Page } from '@/types';

interface NavbarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  streak: number;
}

export function Navbar({ currentPage, onNavigate, streak }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems: { label: string; page: Page }[] = [
    { label: 'Today', page: 'home' },
    { label: 'Lessons', page: 'lessons' },
    { label: 'Progress', page: 'progress' },
    { label: 'About', page: 'about' },
  ];

  const handleNav = (page: Page) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => handleNav('home')}
            className="flex items-center gap-2 font-bold text-xl text-gray-900"
          >
            <span className="flex items-center justify-center w-9 h-9 rounded-lg bg-brand-600 text-white">
              <Code2 size={20} />
            </span>
            PyLearn
          </button>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => handleNav(item.page)}
                className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                  currentPage === item.page || (currentPage === 'lesson' && item.page === 'lessons')
                    ? 'text-brand-700 bg-brand-50'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Streak + mobile toggle */}
          <div className="flex items-center gap-3">
            {streak > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-50 border border-orange-200">
                <Flame size={16} className="text-orange-500" />
                <span className="text-sm font-semibold text-orange-700">{streak} Day Streak</span>
              </div>
            )}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-gray-100"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile nav */}
        {mobileOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-1 animate-fade-in">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => handleNav(item.page)}
                className={`px-4 py-2.5 rounded-lg font-medium text-sm text-left transition-colors ${
                  currentPage === item.page || (currentPage === 'lesson' && item.page === 'lessons')
                    ? 'text-brand-700 bg-brand-50'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
