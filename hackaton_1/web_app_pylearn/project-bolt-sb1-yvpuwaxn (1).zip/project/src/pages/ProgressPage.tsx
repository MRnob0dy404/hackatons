import type { Lesson, ProgressState } from '@/types';
import { isLessonCompleted, isLessonLocked, getWeeklyActivity, getCurrentLessonId, todayISO } from '@/lib/storage';
import { Flame, CheckCircle2, Target, TrendingUp } from 'lucide-react';

interface ProgressPageProps {
  lessons: Lesson[];
  progress: ProgressState;
  onSelectLesson: (lessonId: string) => void;
}

export function ProgressPage({ lessons, progress, onSelectLesson }: ProgressPageProps) {
  const completedCount = progress.completedLessons.length;
  const totalCount = lessons.length;
  const weekly = getWeeklyActivity(progress);
  const currentLessonId = getCurrentLessonId(progress);
  const currentLesson = lessons.find((l) => l.id === currentLessonId);
  const todayDone = progress.lastCompletedDate === todayISO();
  const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const completionPct = Math.round((completedCount / totalCount) * 100);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Progress</h1>
      <p className="text-gray-600 mb-8">Track your learning streak and completed lessons.</p>

      {/* Stats cards */}
      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <Flame size={20} className="text-orange-500" />
            <span className="text-sm font-medium text-gray-500">Current Streak</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{progress.streak}</p>
          <p className="text-sm text-gray-400">day{progress.streak === 1 ? '' : 's'}</p>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle2 size={20} className="text-green-500" />
            <span className="text-sm font-medium text-gray-500">Lessons Completed</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{completedCount}<span className="text-lg text-gray-400"> / {totalCount}</span></p>
          <p className="text-sm text-gray-400">{completionPct}% complete</p>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <Target size={20} className="text-brand-500" />
            <span className="text-sm font-medium text-gray-500">Today</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{todayDone ? 'Done' : 'Open'}</p>
          <p className="text-sm text-gray-400">{todayDone ? 'Come back tomorrow' : 'Lesson waiting'}</p>
        </div>
      </div>

      {/* Progress bar */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-5 mb-8">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold text-gray-700">Overall Progress</span>
          <span className="text-sm font-bold text-brand-600">{completionPct}%</span>
        </div>
        <div className="h-3 rounded-full bg-gray-100 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-brand-500 to-brand-600 rounded-full transition-all duration-500"
            style={{ width: `${completionPct}%` }}
          />
        </div>
      </div>

      {/* Weekly activity */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-5 mb-8">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp size={18} className="text-gray-400" />
          <h2 className="font-semibold text-gray-700">This Week's Activity</h2>
        </div>
        <div className="grid grid-cols-7 gap-2">
          {dayNames.map((day, i) => (
            <div key={day} className="text-center">
              <p className="text-xs text-gray-400 mb-2">{day}</p>
              <div
                className={`h-12 rounded-lg flex items-center justify-center text-sm font-medium ${
                  weekly[i]
                    ? 'bg-green-100 text-green-700 border border-green-200'
                    : 'bg-gray-50 text-gray-300 border border-gray-100'
                }`}
              >
                {weekly[i] ? '✓' : '—'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Learning path */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-5">
        <h2 className="font-semibold text-gray-700 mb-4">Learning Path</h2>
        <div className="space-y-1">
          {lessons.map((lesson, idx) => {
            const completed = isLessonCompleted(progress, lesson.id);
            const isCurrent = lesson.id === currentLessonId && !completed;
            const isLocked = isLessonLocked(progress, lesson.order);

            return (
              <div key={lesson.id}>
                <button
                  onClick={() => !isLocked && onSelectLesson(lesson.id)}
                  disabled={isLocked}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-colors ${
                    isLocked
                      ? 'opacity-50 cursor-not-allowed'
                      : 'hover:bg-gray-50 cursor-pointer'
                  } ${isCurrent ? 'bg-brand-50' : ''}`}
                >
                  {/* Number circle */}
                  <div
                    className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold shrink-0 ${
                      completed
                        ? 'bg-green-500 text-white'
                        : isCurrent
                        ? 'bg-brand-600 text-white'
                        : isLocked
                        ? 'bg-gray-100 text-gray-400'
                        : 'bg-gray-100 text-gray-500'
                    }`}
                  >
                    {completed ? <CheckCircle2 size={16} /> : idx + 1}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className={`font-medium text-sm ${isCurrent ? 'text-brand-700' : 'text-gray-800'}`}>
                      {lesson.title}
                    </p>
                    <p className="text-xs text-gray-400">{lesson.topic}</p>
                  </div>

                  {isCurrent && (
                    <span className="text-xs font-medium text-brand-600 px-2 py-0.5 rounded bg-brand-100 shrink-0">
                      Current
                    </span>
                  )}
                </button>
                {idx < lessons.length - 1 && (
                  <div className="ml-4 w-px h-4 bg-gray-100" />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
