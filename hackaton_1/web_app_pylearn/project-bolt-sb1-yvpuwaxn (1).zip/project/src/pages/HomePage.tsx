import type { Lesson, ProgressState } from '@/types';
import { isLessonCompleted, getCurrentLessonId } from '@/lib/storage';
import { ArrowRight, BookOpen, Clock, BarChart3, Flame, CheckCircle2, Sparkles } from 'lucide-react';

interface HomePageProps {
  lessons: Lesson[];
  progress: ProgressState;
  onStartLesson: (lessonId: string) => void;
  onNavigate: (page: 'lessons' | 'progress' | 'about') => void;
}

export function HomePage({ lessons, progress, onStartLesson, onNavigate }: HomePageProps) {
  const currentLessonId = getCurrentLessonId(progress);
  const currentLesson = lessons.find((l) => l.id === currentLessonId) ?? lessons[0];
  const completed = isLessonCompleted(progress, currentLesson.id);
  const allDone = progress.completedLessons.length >= lessons.length;

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-brand-50 via-white to-brand-50/30">
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #1d44e8 1px, transparent 0)`,
          backgroundSize: '32px 32px',
        }} />
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-16 sm:py-24 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-100 text-brand-700 text-sm font-medium mb-6 animate-fade-in">
            <Sparkles size={15} />
            One concept at a time
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 tracking-tight mb-4 animate-slide-up">
            Learn Python by <span className="text-brand-600">Doing.</span>
          </h1>
          <p className="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto mb-8 animate-slide-up">
            One small lesson. Four practical exercises. Every day.
          </p>
          <button
            onClick={() => onStartLesson(currentLesson.id)}
            className="inline-flex items-center gap-2 px-8 py-4 bg-brand-600 text-white font-semibold rounded-xl hover:bg-brand-700 transition-all hover:shadow-lg hover:shadow-brand-600/20 text-lg animate-slide-up"
          >
            {allDone ? 'Review Lessons' : completed ? 'Continue Learning' : 'Start Learning'}
            <ArrowRight size={20} />
          </button>

          {progress.streak > 0 && (
            <div className="mt-8 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-50 border border-orange-200 animate-pop">
              <Flame size={18} className="text-orange-500" />
              <span className="font-semibold text-orange-700">{progress.streak} Day Streak</span>
            </div>
          )}
        </div>
      </section>

      {/* Current Lesson Card */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 -mt-8 sm:-mt-12 relative z-10">
        <div className="bg-white rounded-2xl border border-gray-200 shadow-card-hover p-6 sm:p-8">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-600">
              {allDone ? 'All Lessons Complete' : completed ? 'Continue With' : 'Start Here'}
            </span>
            {completed && !allDone && (
              <span className="flex items-center gap-1 text-sm font-medium text-green-600">
                <CheckCircle2 size={16} />
                In Progress
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 text-sm font-medium text-brand-600 mb-2">
            <span className="px-2.5 py-1 rounded-md bg-brand-50">Lesson {currentLesson.order}</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">{currentLesson.title}</h2>

          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-6">
            <span className="flex items-center gap-1.5">
              <BookOpen size={15} />
              {currentLesson.topic}
            </span>
            <span className="flex items-center gap-1.5">
              <BarChart3 size={15} />
              {currentLesson.difficulty}
            </span>
            <span className="flex items-center gap-1.5">
              <Clock size={15} />
              {currentLesson.estimatedTime}
            </span>
          </div>

          <p className="text-gray-600 mb-6 leading-relaxed">{currentLesson.explanation}</p>

          <button
            onClick={() => onStartLesson(currentLesson.id)}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-brand-600 text-white font-semibold rounded-xl hover:bg-brand-700 transition-colors"
          >
            {completed ? 'Continue Lesson' : 'Start Lesson'}
            <ArrowRight size={18} />
          </button>
        </div>
      </section>

      {/* Feature cards */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid sm:grid-cols-3 gap-6">
          {[
            { icon: BookOpen, title: 'Short Lessons', desc: 'Bite-sized explanations that take 5 minutes or less to read.' },
            { icon: CheckCircle2, title: 'Guided Practice', desc: 'Four fill-in-the-code exercises per lesson with instant feedback.' },
            { icon: Flame, title: 'Build a Streak', desc: 'Complete a lesson each day to keep your learning streak alive.' },
          ].map((f, i) => (
            <div key={i} className="bg-white rounded-2xl border border-gray-200 shadow-card p-6 hover:shadow-card-hover transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-brand-50 flex items-center justify-center mb-4">
                <f.icon size={22} className="text-brand-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">{f.title}</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 pb-16">
        <div className="bg-gradient-to-r from-brand-600 to-brand-700 rounded-2xl p-8 sm:p-10 text-center">
          <h2 className="text-2xl font-bold text-white mb-3">Ready to start learning?</h2>
          <p className="text-brand-100 mb-6">No sign-up. No installation. Just open and learn.</p>
          <div className="flex flex-wrap justify-center gap-3">
            <button
              onClick={() => onStartLesson(currentLesson.id)}
              className="px-6 py-3 bg-white text-brand-700 font-semibold rounded-xl hover:bg-brand-50 transition-colors"
            >
              {completed ? 'Continue Learning' : 'Start First Lesson'}
            </button>
            <button
              onClick={() => onNavigate('lessons')}
              className="px-6 py-3 bg-brand-500/30 text-white font-semibold rounded-xl hover:bg-brand-500/40 transition-colors border border-white/20"
            >
              Browse All Lessons
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
