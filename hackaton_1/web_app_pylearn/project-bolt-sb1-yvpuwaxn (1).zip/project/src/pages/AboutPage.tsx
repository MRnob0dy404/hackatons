import { Code2, BookOpen, Pencil, Users } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">About PyLearn</h1>

      <div className="space-y-6">
        {/* Purpose */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-4">
            <Code2 size={22} className="text-brand-600" />
            <h2 className="text-xl font-bold text-gray-900">Our Purpose</h2>
          </div>
          <p className="text-gray-700 leading-relaxed">
            PyLearn helps beginners learn Python through short explanations, guided exercises and immediate feedback.
            No teacher, paid course, or software installation required — just open your browser and start learning.
          </p>
        </div>

        {/* Who it's for */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-4">
            <Users size={22} className="text-brand-600" />
            <h2 className="text-xl font-bold text-gray-900">Who It's For</h2>
          </div>
          <ul className="space-y-2.5 text-gray-700">
            {[
              'Absolute beginners with no programming experience',
              'Students learning Python for the first time',
              'Self-learners who prefer a structured, step-by-step approach',
              'People learning programming for the first time',
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-brand-500 mt-2 shrink-0" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        {/* Learning method */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen size={22} className="text-brand-600" />
            <h2 className="text-xl font-bold text-gray-900">How It Works</h2>
          </div>
          <div className="space-y-4 text-gray-700 leading-relaxed">
            <p>
              Each lesson introduces one Python concept with a short explanation, followed by four guided coding exercises.
            </p>
            <p>
              Instead of giving learners a blank editor, PyLearn shows partially completed code and asks you to fill in the missing part.
              You check your answer and get immediate feedback — if you make a mistake, the correct solution is shown with an explanation of why it works.
            </p>
            <div className="flex items-start gap-2.5 p-3 rounded-xl bg-brand-50">
              <Pencil size={18} className="text-brand-600 mt-0.5 shrink-0" />
              <p className="text-sm text-brand-900">Guided fill-in-the-code exercises — never a blank page.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
