import type { Lesson, ProgressState } from '@/types';
import { isLessonCompleted, isLessonLocked, getCurrentLessonId } from '@/lib/storage';
import { CheckCircle2, Lock, BookOpen, BarChart3, Clock } from 'lucide-react';

interface LessonsPageProps {
  lessons: Lesson[];
  progress: ProgressState;
  onSelectLesson: (lessonId: string) => void;
}

export function LessonsPage({ lessons, progress, onSelectLesson }: LessonsPageProps) {
  const currentLessonId = getCurrentLessonId(progress);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">All Lessons</h1>
        <p className="text-gray-600">Complete each lesson to unlock the next one. Every lesson has four exercises.</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {lessons.map((lesson) => {
          const completed = isLessonCompleted(progress, lesson.id);
          const isCurrent = lesson.id === currentLessonId && !completed;
          const isLocked = isLessonLocked(progress, lesson.order);

          return (
            <button
              key={lesson.id}
              onClick={() => !isLocked && onSelectLesson(lesson.id)}
              disabled={isLocked}
              className={`text-left bg-white rounded-2xl border p-5 transition-all ${
                isLocked
                  ? 'border-gray-200 opacity-60 cursor-not-allowed'
                  : 'border-gray-200 shadow-card hover:shadow-card-hover hover:border-brand-300 cursor-pointer'
              } ${isCurrent ? 'ring-2 ring-brand-400' : ''}`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-gray-400">
                  Lesson {lesson.order}
                </span>
                {completed ? (
                  <span className="flex items-center gap-1 text-xs font-medium text-green-600">
                    <CheckCircle2 size={14} />
                    Completed
                  </span>
                ) : isCurrent ? (
                  <span className="text-xs font-medium text-brand-600 px-2 py-0.5 rounded bg-brand-50">
                    Current
                  </span>
                ) : isLocked ? (
                  <Lock size={14} className="text-gray-400" />
                ) : null}
              </div>

              <h3 className="font-bold text-gray-900 mb-1">{lesson.title}</h3>
              <p className="text-sm text-gray-500 mb-4">{lesson.topic}</p>

              <div className="flex items-center gap-3 text-xs text-gray-400">
                <span className="flex items-center gap-1">
                  <BarChart3 size={12} />
                  {lesson.difficulty}
                </span>
                <span className="flex items-center gap-1">
                  <Clock size={12} />
                  {lesson.estimatedTime}
                </span>
                <span className="flex items-center gap-1">
                  <BookOpen size={12} />
                  {lesson.exercises.length} exercises
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
