import { useState } from 'react';
import type { Lesson, ProgressState } from '@/types';
import { CodeBlock } from '@/components/CodeBlock';
import { ExerciseEditor } from '@/components/ExerciseEditor';
import { isLessonCompleted } from '@/lib/storage';
import { ArrowLeft, BookOpen, Pencil, Clock, BarChart3, CheckCircle2, ArrowRight, PartyPopper } from 'lucide-react';

interface LessonViewProps {
  lesson: Lesson;
  progress: ProgressState;
  onBack: () => void;
  onComplete: (lessonId: string) => void;
  onNextLesson?: (lessonId: string) => void;
  hasNextLesson: boolean;
}

export function LessonView({ lesson, progress, onBack, onComplete, onNextLesson, hasNextLesson }: LessonViewProps) {
  const [step, setStep] = useState<'learn' | 'practice' | 'finished'>('learn');
  const [currentExercise, setCurrentExercise] = useState(0);
  const [completedExercises, setCompletedExercises] = useState<Set<number>>(new Set());
  const lessonAlreadyCompleted = isLessonCompleted(progress, lesson.id);

  const totalExercises = lesson.exercises.length;
  const exercise = lesson.exercises[currentExercise];

  const handleExerciseCorrect = () => {
    setCompletedExercises((prev) => {
      const next = new Set(prev);
      next.add(currentExercise);
      return next;
    });
  };

  const handleNextExercise = () => {
    if (currentExercise + 1 < totalExercises) {
      setCurrentExercise(currentExercise + 1);
    } else {
      // All exercises done — mark lesson complete and show finished state
      if (!lessonAlreadyCompleted) {
        onComplete(lesson.id);
      }
      setStep('finished');
    }
  };

  const restartExercises = () => {
    setCurrentExercise(0);
    setCompletedExercises(new Set());
    setStep('practice');
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      {/* Back link */}
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-sm font-medium text-gray-500 hover:text-gray-800 mb-6 transition-colors"
      >
        <ArrowLeft size={16} />
        Back to Lessons
      </button>

      {/* Lesson header */}
      <div className="mb-8 animate-fade-in">
        <div className="flex items-center gap-2 text-sm font-medium text-brand-600 mb-2">
          <span className="px-2.5 py-1 rounded-md bg-brand-50">Lesson {lesson.order}</span>
          {lessonAlreadyCompleted && (
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-green-50 text-green-700">
              <CheckCircle2 size={14} />
              Completed
            </span>
          )}
        </div>
        <h1 className="text-3xl font-bold text-gray-900 mb-3">{lesson.title}</h1>
        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
          <span className="flex items-center gap-1.5">
            <BookOpen size={15} />
            {lesson.topic}
          </span>
          <span className="flex items-center gap-1.5">
            <BarChart3 size={15} />
            {lesson.difficulty}
          </span>
          <span className="flex items-center gap-1.5">
            <Clock size={15} />
            {lesson.estimatedTime}
          </span>
        </div>
      </div>

      {/* Step indicator */}
      {step !== 'finished' && (
        <div className="flex items-center gap-2 mb-8">
          <div
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              step === 'learn' ? 'bg-brand-600 text-white' : 'bg-gray-100 text-gray-500'
            }`}
          >
            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-white/20 text-xs">1</span>
            Learn
          </div>
          <div className="w-8 h-px bg-gray-300" />
          <div
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              step === 'practice' ? 'bg-brand-600 text-white' : 'bg-gray-100 text-gray-500'
            }`}
          >
            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-white/20 text-xs">2</span>
            Practice
          </div>
        </div>
      )}

      {/* Step 1: Learn */}
      {step === 'learn' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-6 sm:p-8">
            <h2 className="text-lg font-bold text-gray-900 mb-3">Explanation</h2>
            <p className="text-gray-700 leading-relaxed">{lesson.explanation}</p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">Example</h3>
            <CodeBlock code={lesson.exampleCode} />
          </div>

          <div className="bg-brand-50 rounded-xl p-5 border border-brand-100">
            <p className="text-brand-900 text-sm leading-relaxed">
              <span className="font-semibold">What this does: </span>
              {lesson.exampleExplanation}
            </p>
          </div>

          <button
            onClick={() => setStep('practice')}
            className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-brand-600 text-white font-semibold rounded-xl hover:bg-brand-700 transition-colors text-lg"
          >
            <Pencil size={20} />
            Start Exercises
          </button>
        </div>
      )}

      {/* Step 2: Practice */}
      {step === 'practice' && (
        <div className="space-y-6 animate-fade-in">
          {/* Exercise progress indicator */}
          <div className="flex items-center justify-between bg-white rounded-xl border border-gray-200 shadow-card px-5 py-4">
            <div>
              <p className="text-sm font-bold text-gray-900">
                Exercise {currentExercise + 1} of {totalExercises}
              </p>
              <p className="text-xs text-gray-400 mt-0.5">
                {completedExercises.size} of {totalExercises} completed
              </p>
            </div>
            {/* Dot progress */}
            <div className="flex items-center gap-2">
              {lesson.exercises.map((_, i) => (
                <div
                  key={i}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    completedExercises.has(i)
                      ? 'bg-green-500'
                      : i === currentExercise
                      ? 'bg-brand-500'
                      : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
          </div>

          <ExerciseEditor
            key={currentExercise}
            exercise={exercise}
            onCorrect={handleExerciseCorrect}
          />

          {/* Next exercise button (only shows after correct answer) */}
          {completedExercises.has(currentExercise) && (
            <button
              onClick={handleNextExercise}
              className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-brand-600 text-white font-semibold rounded-xl hover:bg-brand-700 transition-colors text-lg animate-slide-up"
            >
              {currentExercise + 1 < totalExercises ? (
                <>
                  Next Exercise
                  <ArrowRight size={20} />
                </>
              ) : (
                <>
                  Finish Lesson
                  <CheckCircle2 size={20} />
                </>
              )}
            </button>
          )}

          <button
            onClick={() => setStep('learn')}
            className="flex items-center gap-1.5 text-sm font-medium text-gray-500 hover:text-gray-800 transition-colors"
          >
            <ArrowLeft size={16} />
            Back to explanation
          </button>
        </div>
      )}

      {/* Step 3: Finished */}
      {step === 'finished' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-card p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
              <PartyPopper size={32} className="text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Lesson Complete!</h2>
            <p className="text-gray-600 mb-6">
              You finished all {totalExercises} exercises in "{lesson.title}".
            </p>

            <div className="flex flex-col sm:flex-row justify-center gap-3">
              <button
                onClick={onBack}
                className="px-6 py-3 bg-gray-100 text-gray-700 font-semibold rounded-xl hover:bg-gray-200 transition-colors"
              >
                Back to Lessons
              </button>
              {hasNextLesson && onNextLesson ? (
                <button
                  onClick={() => onNextLesson(lesson.id)}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-brand-600 text-white font-semibold rounded-xl hover:bg-brand-700 transition-colors"
                >
                  Start Next Lesson
                  <ArrowRight size={18} />
                </button>
              ) : (
                <button
                  onClick={restartExercises}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-brand-600 text-white font-semibold rounded-xl hover:bg-brand-700 transition-colors"
                >
                  <Pencil size={18} />
                  Practice Again
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
