export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced';

export interface Exercise {
  id: number;
  instruction: string;
  codeBeforeGap: string;
  codeAfterGap: string;
  correctAnswer: string;
  acceptedAnswers: string[];
  completeSolution: string;
  answerExplanation: string;
}

export interface Lesson {
  id: string;
  order: number;
  title: string;
  topic: string;
  difficulty: Difficulty;
  estimatedTime: string;
  explanation: string;
  exampleCode: string;
  exampleExplanation: string;
  exercises: Exercise[];
}

export interface ProgressState {
  completedLessons: string[];
  streak: number;
  lastCompletedDate: string | null;
  lastStreakUpdateDate: string | null;
}

export type Page = 'home' | 'lessons' | 'progress' | 'about' | 'lesson';

export type FeedbackStatus = 'idle' | 'correct' | 'incorrect';
