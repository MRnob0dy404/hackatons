import type { Lesson } from '@/types';

export const lessons: Lesson[] = [
  {
    id: 'print',
    order: 1,
    title: 'Printing Text',
    topic: 'Print Statements',
    difficulty: 'Beginner',
    estimatedTime: '5 min',
    explanation:
      'The print() function displays text on the screen. It is the simplest way to make Python communicate with you. You place whatever you want to show inside parentheses, and Python prints it out. Text (also called a "string") must be wrapped in quotation marks.',
    exampleCode: `print("Hello, World!")`,
    exampleExplanation:
      'The print() function receives the text "Hello, World!" and displays it on the screen. The quotation marks tell Python that this is text, not a command.',
    exercises: [
      {
        id: 1,
        instruction: 'Fill in the missing part to display the text "Python is fun!" on the screen.',
        codeBeforeGap: 'print(',
        codeAfterGap: ')',
        correctAnswer: '"Python is fun!"',
        acceptedAnswers: ['"Python is fun!"', "'Python is fun!'"],
        completeSolution: 'print("Python is fun!")',
        answerExplanation:
          'The print() function displays whatever is inside the parentheses. The text "Python is fun!" is wrapped in quotation marks so Python treats it as a string.',
      },
      {
        id: 2,
        instruction: 'Fill in the function name used to display text on the screen.',
        codeBeforeGap: '___("Hello!")',
        codeAfterGap: '',
        correctAnswer: 'print',
        acceptedAnswers: ['print'],
        completeSolution: 'print("Hello!")',
        answerExplanation:
          'print is the built-in Python function that displays text. You always write it followed by parentheses containing what you want to show.',
      },
      {
        id: 3,
        instruction: 'Fill in the quotation marks so Python recognizes the text as a string.',
        codeBeforeGap: 'print(',
        codeAfterGap: 'Welcome to PyLearn' + '")',
        correctAnswer: '"',
        acceptedAnswers: ['"', "'"],
        completeSolution: 'print("Welcome to PyLearn")',
        answerExplanation:
          'Strings in Python must be wrapped in matching quotation marks. The opening " starts the string and the closing " ends it.',
      },
      {
        id: 4,
        instruction: 'Fill in the parentheses so the print function displays the number 42.',
        codeBeforeGap: 'print',
        codeAfterGap: '',
        correctAnswer: '(42)',
        acceptedAnswers: ['(42)'],
        completeSolution: 'print(42)',
        answerExplanation:
          'Numbers do not need quotation marks. The print() function can display numbers directly when they are placed inside the parentheses.',
      },
    ],
  },
  {
    id: 'variables',
    order: 2,
    title: 'Using Variables',
    topic: 'Variables',
    difficulty: 'Beginner',
    estimatedTime: '5 min',
    explanation:
      'A variable stores information so you can use it later in your program. You create a variable by choosing a name, using the equals sign (=), and giving it a value. Once stored, you can use the variable name anywhere instead of the raw value.',
    exampleCode: `name = "Alex"\nprint(name)`,
    exampleExplanation:
      'The variable called "name" stores the text "Alex". The print() function then displays the value stored inside the variable.',
    exercises: [
      {
        id: 1,
        instruction: 'Create a variable called "age" and store the number 25 in it.',
        codeBeforeGap: 'age ',
        codeAfterGap: ' 25',
        correctAnswer: '=',
        acceptedAnswers: ['='],
        completeSolution: 'age = 25',
        answerExplanation:
          'The equals sign (=) assigns the value on its right (25) to the variable name on its left (age). Now "age" holds the number 25.',
      },
      {
        id: 2,
        instruction: 'Fill in the variable name so the print function displays the stored value.',
        codeBeforeGap: 'city = "Paris"\nprint(',
        codeAfterGap: ')',
        correctAnswer: 'city',
        acceptedAnswers: ['city'],
        completeSolution: 'city = "Paris"\nprint(city)',
        answerExplanation:
          'The variable "city" stores the text "Paris". Passing the variable name to print() displays the value it holds, not the word "city" itself.',
      },
      {
        id: 3,
        instruction: 'Fill in the equals sign to assign the value 100 to the variable "score".',
        codeBeforeGap: 'score ___ 100',
        codeAfterGap: '',
        correctAnswer: '=',
        acceptedAnswers: ['='],
        completeSolution: 'score = 100',
        answerExplanation:
          'The single equals sign (=) is the assignment operator. It stores the value on the right into the variable on the left.',
      },
      {
        id: 4,
        instruction: 'Change the value of the variable "count" to 5 by filling in the missing part.',
        codeBeforeGap: 'count = 0\ncount ',
        codeAfterGap: ' 5',
        correctAnswer: '=',
        acceptedAnswers: ['='],
        completeSolution: 'count = 0\ncount = 5',
        answerExplanation:
          'You can reassign a variable at any time. Writing count = 5 replaces the old value (0) with the new value (5). The variable always keeps its most recent value.',
      },
    ],
  },
  {
    id: 'data-types',
    order: 3,
    title: 'Data Types',
    topic: 'Data Types',
    difficulty: 'Beginner',
    estimatedTime: '5 min',
    explanation:
      'Python has several basic data types. Text is called a "string" (str). Whole numbers are "integers" (int). Numbers with decimals are "floats" (float). True/false values are "booleans" (bool). The type() function tells you what type a value is.',
    exampleCode: `text = "hello"\nnumber = 42\nprice = 9.99\nprint(type(text))\nprint(type(number))`,
    exampleExplanation:
      'The variable "text" holds a string, "number" holds an integer, and "price" holds a float. The type() function reveals the data type of each value.',
    exercises: [
      {
        id: 1,
        instruction: 'Fill in the function name that tells you the data type of a value.',
        codeBeforeGap: 'print(',
        codeAfterGap: '("PyLearn"))',
        correctAnswer: 'type',
        acceptedAnswers: ['type'],
        completeSolution: 'print(type("PyLearn"))',
        answerExplanation:
          'The type() function returns the data type of whatever you pass it. Here it tells us that "PyLearn" is a string (str).',
      },
      {
        id: 2,
        instruction: 'Fill in the value so the variable "price" becomes a float (decimal number).',
        codeBeforeGap: 'price = ',
        codeAfterGap: '',
        correctAnswer: '9.99',
        acceptedAnswers: ['9.99'],
        completeSolution: 'price = 9.99',
        answerExplanation:
          'A float is a number with a decimal point. Writing 9.99 makes Python store "price" as a float data type.',
      },
      {
        id: 3,
        instruction: 'Fill in the correct value (True or False) so the boolean variable is "True".',
        codeBeforeGap: 'is_ready = ',
        codeAfterGap: '',
        correctAnswer: 'True',
        acceptedAnswers: ['True'],
        completeSolution: 'is_ready = True',
        answerExplanation:
          'Booleans can only be True or False. The capital T is important — Python uses True (not true) for the boolean value.',
      },
      {
        id: 4,
        instruction: 'Fill in the type name that describes whole numbers (integers) in Python.',
        codeBeforeGap: 'number = 42\nprint(',
        codeAfterGap: '(number))',
        correctAnswer: 'type',
        acceptedAnswers: ['type'],
        completeSolution: 'number = 42\nprint(type(number))',
        answerExplanation:
          'The type() function shows that 42 is an integer (int). Integers are whole numbers without a decimal point.',
      },
    ],
  },
  {
    id: 'if-statements',
    order: 4,
    title: 'Making Decisions',
    topic: 'If Statements',
    difficulty: 'Beginner',
    estimatedTime: '5 min',
    explanation:
      'An if statement lets your program make decisions. It checks a condition, and if that condition is true, the indented code underneath runs. If the condition is false, Python skips that code. Comparison operators like == (equal), > (greater), < (less), >= (greater or equal) are used to build conditions.',
    exampleCode: `age = 18\n\nif age >= 18:\n    print("You are an adult")`,
    exampleExplanation:
      'The condition "age >= 18" checks whether age is greater than or equal to 18. Since age is 18, the condition is true, so "You are an adult" is printed.',
    exercises: [
      {
        id: 1,
        instruction: 'Fill in the equality operator (==) to check if score is exactly 100.',
        codeBeforeGap: 'score = 100\n\nif score ___ 100:\n    print("Perfect score!")',
        codeAfterGap: '',
        correctAnswer: '==',
        acceptedAnswers: ['=='],
        completeSolution: 'score = 100\n\nif score == 100:\n    print("Perfect score!")',
        answerExplanation:
          'The == operator checks if two values are equal. A single = assigns a value, but == compares two values. Here score is 100, so the condition is true.',
      },
      {
        id: 2,
        instruction: 'Fill in the greater-than operator (>) so the message prints when temperature is above 30.',
        codeBeforeGap: 'temperature = 35\n\nif temperature ___ 30:\n    print("It is hot!")',
        codeAfterGap: '',
        correctAnswer: '>',
        acceptedAnswers: ['>'],
        completeSolution: 'temperature = 35\n\nif temperature > 30:\n    print("It is hot!")',
        answerExplanation:
          'The > operator checks if the left value is strictly greater than the right value. Since 35 is greater than 30, the condition is true and the message prints.',
      },
      {
        id: 3,
        instruction: 'Fill in the less-than-or-equal operator (<=) so the message prints when age is 13 or younger.',
        codeBeforeGap: 'age = 10\n\nif age ___ 13:\n    print("You are a child")',
        codeAfterGap: '',
        correctAnswer: '<=',
        acceptedAnswers: ['<='],
        completeSolution: 'age = 10\n\nif age <= 13:\n    print("You are a child")',
        answerExplanation:
          'The <= operator checks if the left value is less than or equal to the right value. Since 10 is less than 13, the condition is true.',
      },
      {
        id: 4,
        instruction: 'Fill in the greater-than-or-equal operator (>=) so the message prints when age is 18 or older.',
        codeBeforeGap: 'age = 18\n\nif age ___ 18:\n    print("You are an adult")',
        codeAfterGap: '',
        correctAnswer: '>=',
        acceptedAnswers: ['>='],
        completeSolution: 'age = 18\n\nif age >= 18:\n    print("You are an adult")',
        answerExplanation:
          'The >= operator checks whether the value on the left is greater than or equal to the value on the right. Because age is 18, the condition is true.',
      },
    ],
  },
  {
    id: 'for-loops',
    order: 5,
    title: 'Repeating with For Loops',
    topic: 'For Loops',
    difficulty: 'Beginner',
    estimatedTime: '6 min',
    explanation:
      'A for loop repeats a block of code a specific number of times. The range() function generates a sequence of numbers. For example, range(5) produces the numbers 0, 1, 2, 3, 4. Each time the loop runs, the loop variable takes the next value.',
    exampleCode: `for number in range(5):\n    print(number)`,
    exampleExplanation:
      'The loop runs 5 times. The variable "number" takes the values 0, 1, 2, 3, and 4 in turn, and each one is printed.',
    exercises: [
      {
        id: 1,
        instruction: 'Fill in the function that generates a sequence of numbers from 0 to 4.',
        codeBeforeGap: 'for number in ',
        codeAfterGap: ':\n    print(number)',
        correctAnswer: 'range(5)',
        acceptedAnswers: ['range(5)'],
        completeSolution: 'for number in range(5):\n    print(number)',
        answerExplanation:
          'The range(5) function produces the numbers 0, 1, 2, 3, 4. The for loop iterates over each number and prints it.',
      },
      {
        id: 2,
        instruction: 'Fill in the keyword that starts a for loop.',
        codeBeforeGap: '___ fruit in fruits:\n    print(fruit)',
        codeAfterGap: '',
        correctAnswer: 'for',
        acceptedAnswers: ['for'],
        completeSolution: 'for fruit in fruits:\n    print(fruit)',
        answerExplanation:
          'The "for" keyword begins a loop. It tells Python to go through each item in the list "fruits" one at a time, assigning each to the variable "fruit".',
      },
      {
        id: 3,
        instruction: 'Fill in the loop variable name so each item gets printed.',
        codeBeforeGap: 'for ___ in range(3):\n    print(item)',
        codeAfterGap: '',
        correctAnswer: 'item',
        acceptedAnswers: ['item'],
        completeSolution: 'for item in range(3):\n    print(item)',
        answerExplanation:
          'The loop variable (here "item") takes each value from range(3) — which is 0, 1, 2 — one at a time. The print() function displays each value.',
      },
      {
        id: 4,
        instruction: 'Fill in the range so the loop runs exactly 3 times (0, 1, 2).',
        codeBeforeGap: 'for i in range(',
        codeAfterGap: '):\n    print(i)',
        correctAnswer: '3',
        acceptedAnswers: ['3'],
        completeSolution: 'for i in range(3):\n    print(i)',
        answerExplanation:
          'range(3) produces the numbers 0, 1, 2 — three values total. The loop runs once for each value, printing 0, then 1, then 2.',
      },
    ],
  },
  {
    id: 'while-loops',
    order: 6,
    title: 'Repeating with While Loops',
    topic: 'While Loops',
    difficulty: 'Beginner',
    estimatedTime: '6 min',
    explanation:
      'A while loop repeats as long as a condition stays true. Unlike a for loop, it does not have a fixed count — it keeps going until the condition becomes false. You must update the condition inside the loop, or it will run forever.',
    exampleCode: `count = 1\n\nwhile count <= 3:\n    print(count)\n    count = count + 1`,
    exampleExplanation:
      'The loop starts with count = 1. It prints count, then adds 1. It repeats while count is less than or equal to 3, printing 1, 2, and 3.',
    exercises: [
      {
        id: 1,
        instruction: 'Fill in the condition so the loop runs while count is less than or equal to 3.',
        codeBeforeGap: 'count = 1\n\nwhile count ___ 3:\n    print(count)\n    count = count + 1',
        codeAfterGap: '',
        correctAnswer: '<=',
        acceptedAnswers: ['<='],
        completeSolution: 'count = 1\n\nwhile count <= 3:\n    print(count)\n    count = count + 1',
        answerExplanation:
          'The <= operator means "less than or equal to." The loop continues as long as count is 3 or less. Each time, count increases by 1, so the loop eventually stops.',
      },
      {
        id: 2,
        instruction: 'Fill in the keyword that starts a while loop.',
        codeBeforeGap: '___ running:\n    print("Game is on!")',
        codeAfterGap: '',
        correctAnswer: 'while',
        acceptedAnswers: ['while'],
        completeSolution: 'while running:\n    print("Game is on!")',
        answerExplanation:
          'The "while" keyword starts a loop that repeats as long as the condition is true. Here, the loop keeps printing while "running" is True.',
      },
      {
        id: 3,
        instruction: 'Fill in the less-than operator (<) so the loop runs while number is below 10.',
        codeBeforeGap: 'number = 0\n\nwhile number ___ 10:\n    print(number)\n    number = number + 1',
        codeAfterGap: '',
        correctAnswer: '<',
        acceptedAnswers: ['<'],
        completeSolution: 'number = 0\n\nwhile number < 10:\n    print(number)\n    number = number + 1',
        answerExplanation:
          'The < operator checks if the left value is strictly less than the right. The loop prints 0 through 9, then stops when number reaches 10.',
      },
      {
        id: 4,
        instruction: 'Fill in the update so count increases by 1 each time the loop runs.',
        codeBeforeGap: 'count = 0\n\nwhile count < 5:\n    print(count)\n    count = count ___ 1',
        codeAfterGap: '',
        correctAnswer: '+',
        acceptedAnswers: ['+'],
        completeSolution: 'count = 0\n\nwhile count < 5:\n    print(count)\n    count = count + 1',
        answerExplanation:
          'Without increasing count, the loop would run forever. The line count = count + 1 adds 1 to count each time, so eventually count reaches 5 and the loop stops.',
      },
    ],
  },
  {
    id: 'functions',
    order: 7,
    title: 'Reusable Code with Functions',
    topic: 'Functions',
    difficulty: 'Beginner',
    estimatedTime: '7 min',
    explanation:
      'A function is a reusable block of code that performs a task. You define it with the "def" keyword, give it a name, and add parentheses. You can pass information into a function using parameters. To use a function, you "call" it by writing its name with parentheses.',
    exampleCode: `def greet(name):\n    print("Hello, " + name)\n\ngreet("Sam")`,
    exampleExplanation:
      'The function "greet" takes a parameter called "name". When called with "Sam", it prints "Hello, Sam". Functions let you reuse the same code with different inputs.',
    exercises: [
      {
        id: 1,
        instruction: 'Fill in the keyword used to define a new function in Python.',
        codeBeforeGap: '___ greet(name):\n    print("Hello, " + name)',
        codeAfterGap: '',
        correctAnswer: 'def',
        acceptedAnswers: ['def'],
        completeSolution: 'def greet(name):\n    print("Hello, " + name)',
        answerExplanation:
          'The "def" keyword tells Python you are defining a new function. Without it, Python would not know that "greet" is a function definition.',
      },
      {
        id: 2,
        instruction: 'Fill in the function name to call (run) the greet function.',
        codeBeforeGap: 'def greet(name):\n    print("Hello, " + name)\n\n___("Sam")',
        codeAfterGap: '',
        correctAnswer: 'greet',
        acceptedAnswers: ['greet'],
        completeSolution: 'def greet(name):\n    print("Hello, " + name)\n\ngreet("Sam")',
        answerExplanation:
          'To use a function, you call it by writing its name followed by parentheses. greet("Sam") runs the function with "Sam" as the input.',
      },
      {
        id: 3,
        instruction: 'Fill in the parameter name so the function can use it inside the print statement.',
        codeBeforeGap: 'def greet(___):\n    print("Hello, " + name)',
        codeAfterGap: '',
        correctAnswer: 'name',
        acceptedAnswers: ['name'],
        completeSolution: 'def greet(name):\n    print("Hello, " + name)',
        answerExplanation:
          'The parameter "name" receives the value passed when the function is called. Inside the function, you can use "name" just like any variable.',
      },
      {
        id: 4,
        instruction: 'Fill in the parentheses to call the add function with the numbers 3 and 5.',
        codeBeforeGap: 'def add(a, b):\n    print(a + b)\n\nadd',
        codeAfterGap: '',
        correctAnswer: '(3, 5)',
        acceptedAnswers: ['(3, 5)', '(3,5)'],
        completeSolution: 'def add(a, b):\n    print(a + b)\n\nadd(3, 5)',
        answerExplanation:
          'The function "add" takes two parameters (a and b). Calling add(3, 5) passes 3 as "a" and 5 as "b", so it prints 8.',
      },
    ],
  },
];

export function getLessonById(id: string): Lesson | undefined {
  return lessons.find((l) => l.id === id);
}

export function getLessonByOrder(order: number): Lesson | undefined {
  return lessons.find((l) => l.order === order);
}

export function getFirstLesson(): Lesson {
  return lessons[0];
}

export function getNextLesson(currentId: string): Lesson | undefined {
  const current = getLessonById(currentId);
  if (!current) return undefined;
  return getLessonByOrder(current.order + 1);
}
