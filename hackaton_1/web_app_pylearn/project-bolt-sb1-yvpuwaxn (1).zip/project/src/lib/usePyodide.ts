import { useEffect, useRef, useState, useCallback } from 'react';

// Pyodide CDN
const PYODIDE_URL = 'https://cdn.jsdelivr.net/pyodide/v0.26.2/full/pyodide.js';

let pyodidePromise: Promise<any> | null = null;

function loadPyodideScript(): Promise<any> {
  if (pyodidePromise) return pyodidePromise;

  pyodidePromise = new Promise((resolve, reject) => {
    // Check if already loaded
    if ((window as any).loadPyodide) {
      (window as any).loadPyodide().then(resolve).catch(reject);
      return;
    }

    const script = document.createElement('script');
    script.src = PYODIDE_URL;
    script.async = true;
    script.onload = () => {
      (window as any)
        .loadPyodide()
        .then((pyodide: any) => {
          // Redirect stdout/stderr
          resolve(pyodide);
        })
        .catch(reject);
    };
    script.onerror = () => reject(new Error('Failed to load Pyodide'));
    document.head.appendChild(script);
  });

  return pyodidePromise;
}

export interface PyodideState {
  ready: boolean;
  loading: boolean;
  error: string | null;
  output: string;
  runCode: (code: string) => Promise<void>;
  resetOutput: () => void;
}

export function usePyodide(): PyodideState {
  const [ready, setReady] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [output, setOutput] = useState('');
  const pyodideRef = useRef<any>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    loadPyodideScript()
      .then((pyodide) => {
        if (cancelled) return;
        pyodideRef.current = pyodide;
        setReady(true);
        setLoading(false);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err.message || 'Failed to load Python runtime');
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const runCode = useCallback(async (code: string) => {
    if (!pyodideRef.current) return;
    setOutput('');
    let captured = '';

    try {
      pyodideRef.current.setStdout({
        batched: (s: string) => {
          captured += s + '\n';
        },
      });
      pyodideRef.current.setStderr({
        batched: (s: string) => {
          captured += s + '\n';
        },
      });
      await pyodideRef.current.runPythonAsync(code);
      setOutput(captured.trim() || '(no output)');
    } catch (err: any) {
      setOutput(captured + (err.message || String(err)));
    }
  }, []);

  const resetOutput = useCallback(() => setOutput(''), []);

  return { ready, loading, error, output, runCode, resetOutput };
}
