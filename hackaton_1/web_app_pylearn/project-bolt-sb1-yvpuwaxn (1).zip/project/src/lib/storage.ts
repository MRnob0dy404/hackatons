import type { ProgressState } from '@/types';
import { lessons, getLessonById, getLessonByOrder } from '@/data/lessons';

const STORAGE_KEY = 'pylearn-progress';

const defaultProgress: ProgressState = {
  completedLessons: [],
  streak: 0,
  lastCompletedDate: null,
  lastStreakUpdateDate: null,
};

export function loadProgress(): ProgressState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...defaultProgress };
    const parsed = JSON.parse(raw) as ProgressState;
    return { ...defaultProgress, ...parsed };
  } catch {
    return { ...defaultProgress };
  }
}

export function saveProgress(progress: ProgressState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // ignore storage errors
  }
}

export function todayISO(): string {
  return new Date().toISOString().split('T')[0];
}

/**
 * Mark a lesson as completed and update the streak.
 * The streak only increases once per day, regardless of which or how many lessons are completed.
 */
export function markLessonComplete(
  progress: ProgressState,
  lessonId: string
): ProgressState {
  const today = todayISO();
  const alreadyCompleted = progress.completedLessons.includes(lessonId);

  const completedLessons = alreadyCompleted
    ? progress.completedLessons
    : [...progress.completedLessons, lessonId];

  // Streak logic: only update once per day
  let streak = progress.streak;
  let lastStreakUpdateDate = progress.lastStreakUpdateDate;

  if (progress.lastStreakUpdateDate !== today) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayISO = yesterday.toISOString().split('T')[0];

    if (progress.lastStreakUpdateDate === yesterdayISO) {
      streak = streak + 1;
    } else {
      streak = 1;
    }
    lastStreakUpdateDate = today;
  }

  return {
    completedLessons,
    streak,
    lastCompletedDate: today,
    lastStreakUpdateDate,
  };
}

export function isLessonCompleted(progress: ProgressState, lessonId: string): boolean {
  return progress.completedLessons.includes(lessonId);
}

/**
 * Returns the first lesson that has not been completed yet.
 * For a new user, this is always Lesson 1.
 */
export function getCurrentLessonId(progress: ProgressState): string {
  for (const lesson of lessons) {
    if (!progress.completedLessons.includes(lesson.id)) {
      return lesson.id;
    }
  }
  // All lessons completed — return the last one for review
  return lessons[lessons.length - 1].id;
}

/**
 * A lesson is locked if the previous lesson has not been completed.
 * Lesson 1 is always unlocked.
 */
export function isLessonLocked(progress: ProgressState, lessonOrder: number): boolean {
  if (lessonOrder <= 1) return false;
  const previousLesson = getLessonByOrder(lessonOrder - 1);
  if (!previousLesson) return false;
  return !progress.completedLessons.includes(previousLesson.id);
}

/**
 * Returns an array of 7 booleans for the current week (Mon-Sun),
 * true if that day had a lesson completed.
 */
export function getWeeklyActivity(progress: ProgressState): boolean[] {
  const result: boolean[] = [false, false, false, false, false, false, false];
  const now = new Date();
  const dayOfWeek = (now.getDay() + 6) % 7; // 0 = Monday

  for (let i = 0; i <= dayOfWeek; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() - dayOfWeek + i);
    const iso = d.toISOString().split('T')[0];
    if (progress.lastStreakUpdateDate === iso || progress.lastCompletedDate === iso) {
      result[i] = true;
    }
  }

  return result;
}
