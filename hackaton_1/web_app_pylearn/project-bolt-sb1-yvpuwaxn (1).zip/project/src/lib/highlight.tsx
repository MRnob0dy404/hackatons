const KEYWORDS = new Set([
  'def', 'return', 'if', 'elif', 'else', 'for', 'while', 'in', 'not', 'and',
  'or', 'True', 'False', 'None', 'import', 'from', 'as', 'class', 'try',
  'except', 'finally', 'with', 'lambda', 'pass', 'break', 'continue',
  'global', 'nonlocal', 'is', 'del', 'raise', 'yield', 'assert', 'async', 'await',
]);

const BUILTINS = new Set([
  'print', 'range', 'len', 'int', 'str', 'float', 'bool', 'list', 'dict',
  'set', 'tuple', 'type', 'input', 'sum', 'min', 'max', 'abs', 'round',
  'enumerate', 'zip', 'map', 'filter', 'sorted', 'open', 'format', 'isinstance',
]);

type Token = { text: string; cls: string };

export function highlightPython(code: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;

  while (i < code.length) {
    const ch = code[i];

    // Whitespace
    if (ch === ' ' || ch === '\t' || ch === '\n' || ch === '\r') {
      let text = '';
      while (i < code.length && /[ \t\n\r]/.test(code[i])) {
        text += code[i];
        i++;
      }
      tokens.push({ text, cls: '' });
      continue;
    }

    // Comments
    if (ch === '#') {
      let text = '';
      while (i < code.length && code[i] !== '\n') {
        text += code[i];
        i++;
      }
      tokens.push({ text, cls: 'tok-cmt' });
      continue;
    }

    // Strings (single, double, triple)
    if (ch === '"' || ch === "'") {
      const quote = ch;
      let text = ch;
      i++;
      // Triple-quoted
      if (code[i] === quote && code[i + 1] === quote) {
        text += quote + quote;
        i += 2;
        while (i < code.length) {
          if (code[i] === quote && code[i + 1] === quote && code[i + 2] === quote) {
            text += quote + quote + quote;
            i += 3;
            break;
          }
          text += code[i];
          i++;
        }
      } else {
        while (i < code.length && code[i] !== '\n') {
          text += code[i];
          if (code[i] === quote && code[i - 1] !== '\\') {
            i++;
            break;
          }
          i++;
        }
      }
      tokens.push({ text, cls: 'tok-str' });
      continue;
    }

    // Numbers
    if (/[0-9]/.test(ch)) {
      let text = '';
      while (i < code.length && /[0-9._]/.test(code[i])) {
        text += code[i];
        i++;
      }
      tokens.push({ text, cls: 'tok-num' });
      continue;
    }

    // Identifiers / keywords / builtins
    if (/[a-zA-Z_]/.test(ch)) {
      let text = '';
      while (i < code.length && /[a-zA-Z0-9_]/.test(code[i])) {
        text += code[i];
        i++;
      }
      // Check if followed by ( for function call
      let j = i;
      while (j < code.length && code[j] === ' ') j++;
      const isCall = code[j] === '(';

      if (KEYWORDS.has(text)) {
        tokens.push({ text, cls: 'tok-kw' });
      } else if (BUILTINS.has(text)) {
        tokens.push({ text, cls: 'tok-builtin' });
      } else if (isCall) {
        tokens.push({ text, cls: 'tok-fn' });
      } else {
        tokens.push({ text, cls: '' });
      }
      continue;
    }

    // Operators
    if (/[+\-*/%=<>!&|^~]/.test(ch)) {
      let text = '';
      while (i < code.length && /[+\-*/%=<>!&|^~]/.test(code[i])) {
        text += code[i];
        i++;
      }
      tokens.push({ text, cls: 'tok-op' });
      continue;
    }

    // Punctuation and other characters
    tokens.push({ text: ch, cls: '' });
    i++;
  }

  return tokens;
}

export function renderTokens(tokens: Token[]): React.ReactNode[] {
  return tokens.map((t, idx) => {
    if (t.cls === '') return t.text;
    return <span key={idx} className={t.cls}>{t.text}</span>;
  });
}
