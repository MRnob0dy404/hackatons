import { useState, useEffect, useCallback } from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { HomePage } from '@/pages/HomePage';
import { LessonsPage } from '@/pages/LessonsPage';
import { ProgressPage } from '@/pages/ProgressPage';
import { AboutPage } from '@/pages/AboutPage';
import { LessonView } from '@/pages/LessonView';
import { lessons, getLessonById, getNextLesson } from '@/data/lessons';
import { loadProgress, saveProgress, markLessonComplete } from '@/lib/storage';
import type { Page, ProgressState } from '@/types';

function App() {
  const [page, setPage] = useState<Page>('home');
  const [activeLessonId, setActiveLessonId] = useState<string | null>(null);
  const [progress, setProgress] = useState<ProgressState>(() => loadProgress());

  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  const handleNavigate = (p: Page) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectLesson = (lessonId: string) => {
    setActiveLessonId(lessonId);
    setPage('lesson');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleComplete = useCallback((lessonId: string) => {
    setProgress((prev) => markLessonComplete(prev, lessonId));
  }, []);

  const handleNextLesson = (currentLessonId: string) => {
    const next = getNextLesson(currentLessonId);
    if (next) {
      setActiveLessonId(next.id);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const activeLesson = activeLessonId ? getLessonById(activeLessonId) : null;
  const hasNextLesson = activeLesson ? getNextLesson(activeLesson.id) !== undefined : false;

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar currentPage={page} onNavigate={handleNavigate} streak={progress.streak} />

      <main className="flex-1">
        {page === 'home' && (
          <HomePage
            lessons={lessons}
            progress={progress}
            onStartLesson={handleSelectLesson}
            onNavigate={handleNavigate}
          />
        )}
        {page === 'lessons' && (
          <LessonsPage
            lessons={lessons}
            progress={progress}
            onSelectLesson={handleSelectLesson}
          />
        )}
        {page === 'progress' && (
          <ProgressPage
            lessons={lessons}
            progress={progress}
            onSelectLesson={handleSelectLesson}
          />
        )}
        {page === 'about' && <AboutPage />}
        {page === 'lesson' && activeLesson && (
          <LessonView
            lesson={activeLesson}
            progress={progress}
            onBack={() => handleNavigate('lessons')}
            onComplete={handleComplete}
            onNextLesson={handleNextLesson}
            hasNextLesson={hasNextLesson}
          />
        )}
      </main>

      <Footer />
    </div>
  );
}

export default App;
